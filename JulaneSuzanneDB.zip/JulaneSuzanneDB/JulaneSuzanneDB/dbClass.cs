﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JulaneSuzanneDB
{
    class dbClass
    {
        public int name { get; set; }
        public String path { get; set; }
    }
}
